
document.querySelectorAll('nav a').forEach(a=>{
  if(a.href === window.location.href) a.classList.add('active');
});
